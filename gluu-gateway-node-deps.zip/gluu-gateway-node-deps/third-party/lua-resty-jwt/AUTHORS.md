# Authors
Thank you guys for making this project better!

## Repo Owners
 - [@SkyLothar](https://github.com/skylothar) <allothar@gmail.com>

## Tons of Features
 - Em. [@fermaem](https://github.com/fermaem)
 - Nathan Toone [@toonetown](https://github.com/toonetown)

## Resty.EVP
 - Daniel Hiltgen [@dhiltgen](https://github.com/dhiltgen)
 - ravenscar [@ravenscar](https://github.com/ravenscar)
 - William [@Deadleg](https://github.com/Deadleg)

## Patches and Suggestions
 - Daniel Hiltgen [@dhiltgen](https://github.com/dhiltgen)
 - Jun Hanamaki [@junhanamaki](https://github.com/junhanamaki)

## Resty.HMAC
  - @jkeys089 [lua-resty-hmac](https://github.com/jkeys089/lua-resty-hmac)
